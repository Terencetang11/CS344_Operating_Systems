Instructions on how to compile Assignment #2 Files & Directories:

- Terminal Command for compiling -
gcc --std=c99 -o movies_by_year main.c movie_processing.c file_processing.c program_instructions.c

- Terminal Command for running resulting executable -
./movies_by_year 
